Replace static/js/bravesprouts_tour.js with this version. This update adds Demo Videos to the tour and positions that tour card over the sidebar so it does not cover the videos.
