document.addEventListener("DOMContentLoaded", function () {
  const page = document.querySelector(".restaurant-page");
  const activityId = Number(page?.dataset.activityId || 10);
  const childName = (page?.dataset.childName || "there").trim() || "there";

  const incomingCallScreen = document.getElementById("incomingCallScreen");
  const acceptCall = document.getElementById("acceptCall");
  const declineCall = document.getElementById("declineCall");
  const introScreen = document.getElementById("introScreen");
  const introSplit = document.getElementById("introSplit");
  const screenShareLoading = document.getElementById("screenShareLoading");
  const zoomStage = document.getElementById("zoomStage");

  const orderTitle = document.getElementById("orderTitle");
  const orderNumber = document.getElementById("orderNumber");
  const ingredientDock = document.getElementById("ingredientDock");
  const resetPizzaBtn = document.getElementById("resetPizzaBtn");

  const pizzaShell = document.getElementById("pizzaShell");
  const pizzaCanvas = document.getElementById("pizzaCanvas");
  const pizzaCtx = pizzaCanvas ? pizzaCanvas.getContext("2d") : null;
  const sliceLayer = document.getElementById("sliceLayer");

  const teacherVideoTile = document.getElementById("teacherVideoTile");
  const workerVideoTile = document.getElementById("workerVideoTile");
  const introTeacherTile = document.getElementById("introTeacherTile");
  const introWorkerTile = document.getElementById("introWorkerTile");
  const micControl = document.getElementById("micControl");
  const hangupButton = document.getElementById("hangupButton");
  const quietStatusText = document.getElementById("quietStatusText");

  const TEACHER = "teacher";
  const WORKER = "worker";
  const TARGET_ORDERS = 8;
  const READY_REMINDER_MS = 22000;
  const PASSIVE_DONE_CHUNK_MS = 3300;

  function asset(name) {
    return `/static/images/restaurant/${name}`;
  }

  const WORKER_FRAME_CANDIDATES = {
    small: ["restaurant-worker-mouth-small.png"],
    medium: ["restaurant-worker-mouth-medium.png", "restaurant-worker-mouth-mid.png"],
    large: ["restaurant-worker-mouth-large.png", "restaurant-worker-mouth-open.png"],
    extra: ["restaurant-worker-mouth-extra-large.png", "restaurant-worker-mouth-xlarge.png", "restaurant-worker-mouth-wide.png"]
  };

  const workerLoadedFrames = {
    small: asset("restaurant-worker-mouth-small.png")
  };

  function imageLoads(src) {
    return new Promise(resolve => {
      const image = new Image();
      image.onload = () => resolve(true);
      image.onerror = () => resolve(false);
      image.src = src;
    });
  }

  async function preloadWorkerFrames() {
    const entries = Object.entries(WORKER_FRAME_CANDIDATES);

    for (const [frameName, filenames] of entries) {
      for (const filename of filenames) {
        const src = asset(filename);
        // eslint-disable-next-line no-await-in-loop
        if (await imageLoads(src)) {
          workerLoadedFrames[frameName] = src;
          break;
        }
      }
    }

    setWorkerFrame("small");
  }


  const INGREDIENTS = {
    crustClassic: { id: "crustClassic", label: "Classic crust", kind: "crust", image: asset("crust-classic.png"), spoken: "classic crust" },
    crustThin: { id: "crustThin", label: "Thin crust", kind: "crust", image: asset("crust-thin.png"), spoken: "thin crust" },
    crustThick: { id: "crustThick", label: "Thick crust", kind: "crust", image: asset("crust-thick.png"), spoken: "thick crust" },

    tomatoSauce: { id: "tomatoSauce", label: "Tomato sauce", kind: "sauce", image: asset("sauce-tomato-stamp.png"), spoken: "tomato sauce" },
    pestoSauce: { id: "pestoSauce", label: "Pesto", kind: "sauce", image: asset("sauce-pesto-stamp.png"), spoken: "pesto" },
    whiteSauce: { id: "whiteSauce", label: "White sauce", kind: "sauce", image: asset("sauce-white-stamp.png"), spoken: "white sauce" },

    mozzarella: { id: "mozzarella", label: "Mozzarella", kind: "cheese", image: asset("cheese-mozzarella-stamp.png"), spoken: "mozzarella" },
    cheddar: { id: "cheddar", label: "Cheddar", kind: "cheese", image: asset("cheese-cheddar-stamp.png"), spoken: "cheddar" },
    extraCheese: { id: "extraCheese", label: "Extra cheese", kind: "cheese", image: asset("cheese-extra-stamp.png"), spoken: "extra cheese" },

    pepperoni: { id: "pepperoni", label: "Pepperoni", kind: "topping", image: asset("topping-pepperoni.png"), spoken: "pepperoni" },
    mushrooms: { id: "mushrooms", label: "Mushrooms", kind: "topping", image: asset("topping-mushroom.png"), spoken: "mushrooms" },
    peppers: { id: "peppers", label: "Peppers", kind: "topping", image: asset("topping-pepper.png"), spoken: "peppers" },
    olives: { id: "olives", label: "Olives", kind: "topping", image: asset("topping-olive.png"), spoken: "olives" },
    pineapple: { id: "pineapple", label: "Pineapple", kind: "topping", image: asset("topping-pineapple.png"), spoken: "pineapple" },
    tomatoes: { id: "tomatoes", label: "Tomatoes", kind: "topping", image: asset("topping-tomato.png"), spoken: "tomatoes" },
    basil: { id: "basil", label: "Basil", kind: "topping", image: asset("topping-basil.png"), spoken: "basil" },
    onions: { id: "onions", label: "Onions", kind: "topping", image: asset("topping-onion.png"), spoken: "onions" }
  };

  const INGREDIENT_CATEGORIES = [
    { id: "crust", label: "Crust", ids: ["crustClassic", "crustThin", "crustThick"] },
    { id: "sauce", label: "Sauce", ids: ["tomatoSauce", "pestoSauce", "whiteSauce"] },
    { id: "cheese", label: "Cheese", ids: ["mozzarella", "cheddar", "extraCheese"] },
    { id: "toppings", label: "Toppings", ids: ["pepperoni", "mushrooms", "peppers", "olives", "pineapple", "tomatoes", "basil", "onions"] }
  ];

  const ORDERS = [
    { id: "cheese", name: "Cheese Pizza", target: "sauce and cheese" },
    { id: "extra_cheese", name: "Extra Cheese Pizza", target: "extra cheese" },
    { id: "pepperoni", name: "Pepperoni Pizza", target: "pepperoni" },
    { id: "garden", name: "Garden Pizza", target: "colorful toppings" },
    { id: "table", name: "Teacher's Table Pizza", target: "a pizza for the table" },
    { id: "family", name: "Family Pizza", target: "a pizza to share" },
    { id: "favorite", name: "Customer Favorite", target: "a favorite pizza" },
    { id: "special", name: "Create Your Own Pizza", target: "your special pizza" }
  ];

  const ringtone = new Audio("/static/images/ringtone.mp3");
  ringtone.loop = true;
  ringtone.volume = 0.35;

  const callAcceptedSound = new Audio("/static/images/call_accepted.mp3");
  callAcceptedSound.volume = 0.45;

  let state = freshState();
  let selectedIngredientId = "tomatoSauce";
  let activeIngredientCategory = "sauce";
  let pointerDown = false;
  let activePointerId = null;
  let lastBrushAt = 0;
  let orderInteractionCount = 0;
  let orderPromptAsked = false;
  let lastCharacterCommentAt = 0;
  let recentLineKeys = [];
  let readyReminderTimer = null;
  let sliceRetries = 0;
  let ringtoneStarted = false;
  let callAccepted = false;

  let speechQueue = Promise.resolve();
  let currentAudio = null;
  let audioContext = null;
  let analyser = null;
  let sourceNode = null;
  let mouthAnimationFrame = null;
  let activeMouthActor = null;

  let mediaStream = null;
  let responseRecorder = null;
  let responseChunks = [];
  let responseTimer = null;
  let responseRecognition = null;
  let responseFinished = false;

  let passiveEnabled = false;
  let passiveRecognition = null;
  let passiveRestartTimer = null;
  let passiveRecorder = null;
  let passiveChunks = [];
  let passiveTimer = null;
  let passiveTranscribing = false;
  let passiveLastText = "";
  let passiveLastAt = 0;

  function freshState() {
    return {
      sessionStart: Date.now(),
      orderIndex: 0,
      ordersCompleted: 0,
      stepsCompleted: 0,
      spokenResponses: 0,
      spokenWords: 0,
      silentWindows: 0,
      workerDirectResponses: 0,
      teacherRedirects: 0,
      totalChoices: 0,
      isSpeaking: false,
      isListening: false,
      waitingForResponse: false,
      micReady: false,
      micDenied: false,
      phase: "making",
      currentQuestion: null,
      gameCompleted: false,
      pizza: freshPizzaState()
    };
  }

  function freshPizzaState() {
    return {
      crust: "crustClassic",
      operations: [],
      sauceStamps: 0,
      cheeseStamps: 0,
      toppings: [],
      baked: false,
      slices: 0,
      boxed: false
    };
  }

  function currentOrder() {
    return ORDERS[Math.min(state.orderIndex, ORDERS.length - 1)];
  }

  function socialStage() {
    if (state.orderIndex <= 1) return "worker_observes";
    if (state.orderIndex <= 3) return "worker_wonders";
    if (state.orderIndex <= 5) return "worker_to_teacher_bridge";
    return "worker_direct";
  }

  function hasRealChildName() {
    return childName && childName.toLowerCase() !== "there";
  }

  function childPrefix() {
    return hasRealChildName() ? `${childName}, ` : "";
  }

  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  function cleanText(text) {
    return String(text || "").replace(/\s+/g, " ").trim();
  }

  function normalizedWords(text) {
    return cleanText(text).toLowerCase().split(/[^a-z0-9]+/).filter(Boolean);
  }

  function countWords(text) {
    return normalizedWords(text).length;
  }

  function updateQuietStatus(text) {
    if (quietStatusText) quietStatusText.textContent = text || "Pizza station ready";
  }

  function startRingtone() {
    if (callAccepted || ringtoneStarted) return;
    ringtone.play().then(() => { ringtoneStarted = true; }).catch(() => {});
  }

  function stopRingtone() {
    ringtone.pause();
    ringtone.currentTime = 0;
    ringtoneStarted = false;
  }

  function playCallAcceptedSound() {
    callAcceptedSound.currentTime = 0;
    return callAcceptedSound.play().catch(() => {});
  }

  function dashboardFade() {
    cleanupMedia();
    window.location.href = "/dashboard";
  }

  function updateMicIndicator() {
    if (!micControl) return;
    micControl.classList.toggle("quiet-listening", Boolean(passiveEnabled || state.isListening || state.waitingForResponse));
  }

  function actorLabel(actor) {
    return actor === WORKER ? "Restaurant Worker" : "Teacher";
  }

  function teacherMouthElements() {
    return [
      document.getElementById("introTeacherMouth"),
      document.getElementById("teacherMouth")
    ].filter(Boolean);
  }

  function workerFrameElements() {
    return [
      document.getElementById("introWorkerCharacter"),
      document.getElementById("workerCharacter")
    ].filter(Boolean);
  }

  function tileForActor(actor) {
    return actor === WORKER ? workerVideoTile : teacherVideoTile;
  }

  function frameForVolume(avg) {
    if (avg > 48 && workerLoadedFrames.extra) return "extra";
    if (avg > 31 && workerLoadedFrames.large) return "large";
    if (avg > 14 && workerLoadedFrames.medium) return "medium";
    return "small";
  }

  function setWorkerFrame(frameName) {
    const src = workerLoadedFrames[frameName] || workerLoadedFrames.small || asset("restaurant-worker-mouth-small.png");
    workerFrameElements().forEach(img => {
      if (!img) return;
      const current = img.getAttribute("src") || "";
      if (!current.endsWith(src.replace("/static/images/restaurant/", ""))) {
        img.src = src;
      }
      img.dataset.workerFrame = frameName;
    });
  }

  function closeAllMouths() {
    teacherMouthElements().forEach(mouth => {
      mouth.style.transform = "translateX(-50%) scale(1)";
    });

    setWorkerFrame("small");
  }

  function stopMouthAnimation() {
    if (mouthAnimationFrame) cancelAnimationFrame(mouthAnimationFrame);
    mouthAnimationFrame = null;
    if (sourceNode) {
      try { sourceNode.disconnect(); } catch (error) {}
      sourceNode = null;
    }
    if (analyser) {
      try { analyser.disconnect(); } catch (error) {}
      analyser = null;
    }
    activeMouthActor = null;
    closeAllMouths();
  }

  function startMouthAnimationForAudio(audio, actor) {
    stopMouthAnimation();
    activeMouthActor = actor;

    try {
      audioContext = audioContext || new (window.AudioContext || window.webkitAudioContext)();
      if (audioContext.state === "suspended") audioContext.resume().catch(() => {});
      analyser = audioContext.createAnalyser();
      analyser.fftSize = 256;
      sourceNode = audioContext.createMediaElementSource(audio);
      sourceNode.connect(analyser);
      analyser.connect(audioContext.destination);
      const data = new Uint8Array(analyser.frequencyBinCount);

      function animate() {
        if (!analyser || activeMouthActor !== actor) return;
        analyser.getByteFrequencyData(data);
        let sum = 0;
        for (let i = 0; i < data.length; i += 1) sum += data[i];
        const avg = sum / data.length;

        if (actor === WORKER) {
          setWorkerFrame(frameForVolume(avg));
        } else {
          const scaleY = 1 + Math.min(0.95, avg / 70);
          const scaleX = 1 + Math.min(0.16, avg / 420);
          teacherMouthElements().forEach(mouth => {
            mouth.style.transform = `translateX(-50%) scale(${scaleX}, ${scaleY})`;
          });
        }

        mouthAnimationFrame = requestAnimationFrame(animate);
      }
      animate();
    } catch (error) {
      let frameIndex = 0;
      const workerFallbackFrames = ["small", "medium", "large", "extra"].filter(frame => workerLoadedFrames[frame]);
      let teacherOpen = false;

      function fallback() {
        if (activeMouthActor !== actor) return;

        if (actor === WORKER) {
          const frames = workerFallbackFrames.length ? workerFallbackFrames : ["small"];
          frameIndex = (frameIndex + 1) % frames.length;
          setWorkerFrame(frames[frameIndex]);
        } else {
          teacherOpen = !teacherOpen;
          teacherMouthElements().forEach(mouth => {
            mouth.style.transform = `translateX(-50%) scale(1, ${teacherOpen ? 1.45 : 1})`;
          });
        }

        mouthAnimationFrame = requestAnimationFrame(fallback);
      }
      fallback();
    }
  }

  function rememberLineKey(key) {
    recentLineKeys.push(key);
    if (recentLineKeys.length > 24) recentLineKeys.shift();
  }

  function pickUnique(key, lines) {
    const available = lines.filter((_, index) => !recentLineKeys.includes(`${key}:${index}`));
    const pool = available.length ? available : lines;
    const line = pool[Math.floor(Math.random() * pool.length)];
    rememberLineKey(`${key}:${lines.indexOf(line)}`);
    return line;
  }

  async function speakNow(actor, text, options = {}) {
    const message = cleanText(typeof text === "function" ? text() : text);
    if (!message || state.gameCompleted) return;

    state.isSpeaking = true;
    updateMicIndicator();
    updateQuietStatus(`${actorLabel(actor)} is talking`);
    tileForActor(actor)?.classList.add("speaking");
    pausePassiveDoneListenForResponse();

    try {
      const response = await fetch("/api/restaurant-game/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ speaker: actor, text: message, game_complete: Boolean(options.gameComplete) })
      });
      const data = await response.json();
      if (data.success && data.audio) {
        currentAudio = new Audio(data.audio);
        currentAudio.volume = options.volume || 0.92;
        await new Promise(resolve => {
          let resolved = false;
          function finish() {
            if (resolved) return;
            resolved = true;
            resolve();
          }
          currentAudio.addEventListener("play", () => startMouthAnimationForAudio(currentAudio, actor), { once: true });
          currentAudio.addEventListener("ended", finish, { once: true });
          currentAudio.addEventListener("error", finish, { once: true });
          currentAudio.play().catch(finish);
          setTimeout(finish, Math.max(2200, message.length * 95));
        });
      } else {
        await sleep(Math.min(1700, 550 + message.length * 18));
      }
    } catch (error) {
      console.warn("Restaurant TTS error:", error);
      await sleep(Math.min(1700, 550 + message.length * 18));
    } finally {
      tileForActor(actor)?.classList.remove("speaking");
      stopMouthAnimation();
      state.isSpeaking = false;
      currentAudio = null;
      updateQuietStatus("Pizza station ready");
      updateMicIndicator();
    }

    if (options.expectsResponse) {
      await startResponseWindow({
        actor,
        message,
        source: options.source || actor,
        intent: options.intent || null,
        askType: options.askType || "choice"
      }, options.responseSeconds || 5.5);
    } else if (!state.gameCompleted && !state.waitingForResponse && state.phase === "making") {
      schedulePassiveDoneListen(350);
    }
  }

  function queueSpeak(actor, text, options = {}) {
    speechQueue = speechQueue.then(() => speakNow(actor, text, options)).catch(error => {
      console.error("Restaurant speech queue error:", error);
    });
    return speechQueue;
  }

  async function ensureMicPermission() {
    if (state.micDenied) return null;
    if (mediaStream) return mediaStream;
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      state.micDenied = true;
      updateMicIndicator();
      return null;
    }
    try {
      mediaStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      state.micReady = true;
      updateMicIndicator();
      return mediaStream;
    } catch (error) {
      state.micDenied = true;
      updateMicIndicator();
      return null;
    }
  }

  function getSupportedMimeType() {
    const options = ["audio/webm;codecs=opus", "audio/webm", "audio/mp4"];
    for (const option of options) {
      if (window.MediaRecorder && MediaRecorder.isTypeSupported(option)) return option;
    }
    return "";
  }

  function getSpeechRecognitionConstructor() {
    return window.SpeechRecognition || window.webkitSpeechRecognition || null;
  }

  function stopResponseWindow() {
    if (responseTimer) clearTimeout(responseTimer);
    responseTimer = null;
    if (responseRecognition) {
      try { responseRecognition.stop(); } catch (error) {}
      responseRecognition = null;
    }
    if (responseRecorder && responseRecorder.state !== "inactive") {
      try { responseRecorder.stop(); } catch (error) {}
    }
  }

  async function startResponseWindow(question, seconds) {
    const stream = await ensureMicPermission();
    if (!stream) {
      await handleNoSpeech(question);
      return;
    }

    state.isListening = true;
    state.waitingForResponse = true;
    state.currentQuestion = question;
    responseFinished = false;
    responseChunks = [];
    updateMicIndicator();
    pausePassiveDoneListenForResponse();

    let browserTranscript = "";
    const Recognition = getSpeechRecognitionConstructor();
    if (Recognition) {
      try {
        responseRecognition = new Recognition();
        responseRecognition.continuous = true;
        responseRecognition.interimResults = true;
        responseRecognition.lang = "en-US";
        responseRecognition.onresult = event => {
          let text = "";
          for (let i = 0; i < event.results.length; i += 1) {
            text += " " + (event.results[i][0]?.transcript || "");
          }
          browserTranscript = cleanText(text);
          if (shouldUseTranscriptImmediately(question, browserTranscript)) {
            finishResponseWindow(question, browserTranscript);
          }
        };
        responseRecognition.onerror = () => {};
        responseRecognition.start();
      } catch (error) {
        responseRecognition = null;
      }
    }

    try {
      const mimeType = getSupportedMimeType();
      responseRecorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);
    } catch (error) {
      responseRecorder = new MediaRecorder(stream);
    }

    responseRecorder.addEventListener("dataavailable", event => {
      if (event.data && event.data.size > 0) responseChunks.push(event.data);
    });

    responseRecorder.addEventListener("stop", async function () {
      if (responseFinished) return;
      let transcript = browserTranscript;
      if (!transcript && responseChunks.length) {
        transcript = await transcribeChunks(responseChunks, "restaurant-response.webm");
      }
      await finishResponseWindow(question, transcript);
    }, { once: true });

    try { responseRecorder.start(); } catch (error) {}

    responseTimer = setTimeout(function () {
      if (responseRecognition) {
        try { responseRecognition.stop(); } catch (error) {}
        responseRecognition = null;
      }
      if (responseRecorder && responseRecorder.state !== "inactive") {
        try { responseRecorder.stop(); } catch (error) { finishResponseWindow(question, browserTranscript); }
      } else {
        finishResponseWindow(question, browserTranscript);
      }
    }, Math.max(1800, seconds * 1000));
  }

  function shouldUseTranscriptImmediately(question, transcript) {
    if (!transcript) return false;
    if (question?.intent === "ready") return classifyReadyResponse(transcript) !== "unclear";
    if (question?.intent === "slice") return Boolean(parseSliceCount(transcript));
    if (question?.intent === "ingredient") return Boolean(ingredientIdFromSpeech(transcript));
    return countWords(transcript) >= 1;
  }

  async function finishResponseWindow(question, transcript) {
    if (responseFinished) return;
    responseFinished = true;
    if (responseTimer) clearTimeout(responseTimer);
    responseTimer = null;
    if (responseRecognition) {
      try { responseRecognition.stop(); } catch (error) {}
      responseRecognition = null;
    }
    if (responseRecorder && responseRecorder.state !== "inactive") {
      try { responseRecorder.stop(); } catch (error) {}
    }
    responseRecorder = null;
    state.isListening = false;
    state.waitingForResponse = false;
    state.currentQuestion = null;
    updateMicIndicator();

    const cleaned = cleanText(transcript);
    if (cleaned) {
      await handleSpeech(cleaned, question);
    } else {
      await handleNoSpeech(question);
    }

    if (!state.gameCompleted && state.phase === "making") schedulePassiveDoneListen(450);
  }

  async function transcribeChunks(chunks, filename) {
    if (!chunks || !chunks.length) return "";
    try {
      const blob = new Blob(chunks, { type: chunks[0]?.type || "audio/webm" });
      const formData = new FormData();
      formData.append("audio", blob, filename);
      const response = await fetch("/api/restaurant-game/transcribe", { method: "POST", body: formData });
      const data = await response.json();
      return data.success ? cleanText(data.text || "") : "";
    } catch (error) {
      console.warn("Restaurant transcription error:", error);
      return "";
    }
  }

  function pausePassiveDoneListenForResponse() {
    if (passiveRestartTimer) clearTimeout(passiveRestartTimer);
    passiveRestartTimer = null;
    if (passiveRecognition) {
      try { passiveRecognition.stop(); } catch (error) {}
      passiveRecognition = null;
    }
    if (passiveTimer) clearTimeout(passiveTimer);
    passiveTimer = null;
    if (passiveRecorder && passiveRecorder.state !== "inactive") {
      try { passiveRecorder.stop(); } catch (error) {}
    }
    passiveRecorder = null;
    passiveChunks = [];
    updateMicIndicator();
  }

  function stopPassiveDoneListen() {
    passiveEnabled = false;
    pausePassiveDoneListenForResponse();
    updateMicIndicator();
  }

  function schedulePassiveDoneListen(delayMs = 600) {
    if (state.gameCompleted || state.phase === "baking" || state.phase === "finishing") return;
    passiveEnabled = true;
    updateMicIndicator();
    if (passiveRestartTimer) clearTimeout(passiveRestartTimer);
    passiveRestartTimer = setTimeout(startPassiveDoneListen, Math.max(0, delayMs));
  }

  async function startPassiveDoneListen() {
    passiveRestartTimer = null;
    if (!passiveEnabled || state.isSpeaking || state.isListening || state.waitingForResponse || state.gameCompleted) {
      if (passiveEnabled) schedulePassiveDoneListen(550);
      return;
    }

    const Recognition = getSpeechRecognitionConstructor();
    if (Recognition) {
      try {
        passiveRecognition = new Recognition();
        passiveRecognition.continuous = true;
        passiveRecognition.interimResults = true;
        passiveRecognition.lang = "en-US";
        passiveRecognition.onresult = event => {
          for (let i = event.resultIndex; i < event.results.length; i += 1) {
            const transcript = cleanText(event.results[i][0]?.transcript || "");
            if (transcript) handlePassiveTranscript(transcript);
          }
        };
        passiveRecognition.onerror = () => {
          passiveRecognition = null;
          schedulePassiveDoneListen(700);
        };
        passiveRecognition.onend = () => {
          passiveRecognition = null;
          if (passiveEnabled && !state.gameCompleted) schedulePassiveDoneListen(300);
        };
        passiveRecognition.start();
      } catch (error) {
        passiveRecognition = null;
        startPassiveRecorderChunk();
      }
    } else {
      startPassiveRecorderChunk();
    }
  }

  async function startPassiveRecorderChunk() {
    if (passiveTranscribing || !passiveEnabled || state.isSpeaking || state.isListening || state.waitingForResponse) {
      schedulePassiveDoneListen(650);
      return;
    }
    const stream = await ensureMicPermission();
    if (!stream) return;
    passiveChunks = [];
    try {
      const mimeType = getSupportedMimeType();
      passiveRecorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);
    } catch (error) {
      passiveRecorder = new MediaRecorder(stream);
    }
    passiveRecorder.addEventListener("dataavailable", event => {
      if (event.data && event.data.size > 0) passiveChunks.push(event.data);
    });
    passiveRecorder.addEventListener("stop", async function () {
      if (!passiveEnabled || passiveTranscribing || !passiveChunks.length) {
        schedulePassiveDoneListen(450);
        return;
      }
      passiveTranscribing = true;
      const transcript = await transcribeChunks(passiveChunks, "restaurant-passive.webm");
      passiveTranscribing = false;
      if (transcript) handlePassiveTranscript(transcript);
      if (passiveEnabled && !state.gameCompleted) schedulePassiveDoneListen(300);
    }, { once: true });
    try { passiveRecorder.start(); } catch (error) { schedulePassiveDoneListen(700); return; }
    passiveTimer = setTimeout(() => {
      if (passiveRecorder && passiveRecorder.state !== "inactive") {
        try { passiveRecorder.stop(); } catch (error) { schedulePassiveDoneListen(700); }
      }
    }, PASSIVE_DONE_CHUNK_MS);
  }

  function handlePassiveTranscript(transcript) {
    const cleaned = cleanText(transcript);
    if (!cleaned) return;
    const now = Date.now();
    const lower = cleaned.toLowerCase();
    if (lower === passiveLastText && now - passiveLastAt < 1200) return;
    passiveLastText = lower;
    passiveLastAt = now;

    if (state.phase === "confirm_ready" && classifyReadyResponse(cleaned) === "ready") {
      stopPassiveDoneListen();
      bakePizza();
      return;
    }

    if (state.phase === "confirm_ready" && classifyReadyResponse(cleaned) === "more") {
      stopPassiveDoneListen();
      speakNow(TEACHER, "Okay. You can add a little more. Whenever you're ready, just let me know and we can put it in the oven.").then(() => {
        state.phase = "making";
        schedulePassiveDoneListen(650);
      });
      return;
    }

    if (state.phase === "making" && transcriptHasDoneIntent(cleaned)) {
      stopPassiveDoneListen();
      askReadyForOven();
    }
  }

  async function handleSpeech(transcript, question = {}) {
    state.spokenResponses += 1;
    state.spokenWords += countWords(transcript);

    if (question.source === "worker-direct") state.workerDirectResponses += 1;
    if (question.source === "teacher-redirect") state.teacherRedirects += 1;

    if (question.intent === "ingredient") {
      const ingredientId = ingredientIdFromSpeech(transcript);
      if (ingredientId) {
        await selectIngredient(ingredientId, { fromSpeech: true });
        await speakNow(question.source === "worker-direct" ? WORKER : TEACHER, `Great choice. You can add ${INGREDIENTS[ingredientId].spoken} on the pizza now.`);
      } else {
        await speakNow(TEACHER, "That makes sense. You can also choose any option on the side.");
      }
      return;
    }

    if (question.intent === "ready") {
      const choice = classifyReadyResponse(transcript);
      if (choice === "ready") {
        await bakePizza();
        return;
      }
      if (choice === "more") {
        state.phase = "making";
        await speakNow(TEACHER, "Okay. Add anything else you want. Whenever you're ready, just let me know and we can put it in the oven.");
        scheduleReadyReminder(READY_REMINDER_MS);
        schedulePassiveDoneListen(650);
        return;
      }
      await speakNow(TEACHER, "I might have missed that. You can say ready for the oven, or say add more.", {
        expectsResponse: true,
        source: "teacher-retry",
        intent: "ready",
        responseSeconds: 6.0
      });
      return;
    }

    if (question.intent === "slice") {
      const count = parseSliceCount(transcript);
      if (count) {
        await chooseSlices(count, { fromSpeech: true });
        return;
      }
      await handleSliceNoAnswer();
      return;
    }

    await speakNow(TEACHER, "Nice answer. Let's keep going.");
  }

  async function handleNoSpeech(question = {}) {
    state.silentWindows += 1;
    if (question.intent === "ready") {
      state.phase = "making";
      await speakNow(TEACHER, pickUnique("ready_silence", [
        "That's okay. You can keep working. Whenever you're ready, just let me know and we can put it in the oven.",
        "No rush. Add anything else you want, and tell me when it feels ready.",
        "That's okay. We can wait. Just say done when you want to put it in the oven."
      ]));
      scheduleReadyReminder(READY_REMINDER_MS);
      schedulePassiveDoneListen(650);
      return;
    }
    if (question.intent === "slice") {
      await handleSliceNoAnswer();
      return;
    }
    if (question.source === "worker-direct") {
      await speakNow(TEACHER, "That's okay. You can show us by choosing an option on the side.");
      return;
    }
    await speakNow(TEACHER, "That's okay. We can keep making the pizza.");
  }

  function transcriptHasDoneIntent(text) {
    const lower = cleanText(text).toLowerCase();
    return [
      "i'm done", "im done", "i am done", "done", "all done", "ready", "it's ready", "its ready",
      "finished", "finish", "oven", "bake it", "put it in the oven", "ready for the oven"
    ].some(phrase => lower.includes(phrase));
  }

  function classifyReadyResponse(text) {
    const lower = cleanText(text).toLowerCase();
    if (!lower) return "unclear";
    const morePhrases = ["not ready", "not yet", "more", "add more", "keep going", "keep working", "wait", "no", "nope", "nah"];
    if (morePhrases.some(phrase => lower.includes(phrase))) return "more";
    const readyPhrases = ["yes", "yeah", "yep", "yup", "sure", "okay", "ok", "ready", "done", "finished", "oven", "bake", "put it in", "let's do it", "lets do it"];
    if (readyPhrases.some(phrase => lower.includes(phrase))) return "ready";
    return "unclear";
  }

  function pizzaHasEnoughForOven() {
    return Boolean(state.pizza.crust) && (
      state.pizza.sauceStamps >= 2 ||
      state.pizza.cheeseStamps >= 2 ||
      state.pizza.toppings.length >= 1 ||
      state.pizza.operations.length >= 4
    );
  }

  async function askReadyForOven() {
    if (state.phase !== "making" || state.gameCompleted) return;
    clearReadyReminder();
    if (!pizzaHasEnoughForOven()) {
      await speakNow(TEACHER, pickUnique("not_enough", [
        "Let's add a little more first. A crust with some sauce, cheese, or toppings will help before the oven.",
        "This pizza needs a little more before the oven. You can paint sauce, sprinkle cheese, or add toppings.",
        "Almost. Let's add one or two things first, then we can put it in the oven."
      ]));
      scheduleReadyReminder(READY_REMINDER_MS);
      schedulePassiveDoneListen(650);
      return;
    }

    state.phase = "confirm_ready";
    stopPassiveDoneListen();
    const mode = socialStage();
    if (mode === "worker_direct") {
      await speakNow(WORKER, `${childPrefix()}do you think this pizza is ready for the oven, or do you want to add more?`, {
        expectsResponse: true,
        source: "worker-direct",
        intent: "ready",
        responseSeconds: 7.0
      });
    } else if (mode === "worker_to_teacher_bridge") {
      await speakNow(WORKER, "Teacher, do you think this pizza is ready for the oven?");
      await speakNow(TEACHER, `${childPrefix()}what do you think? Is it ready for the oven, or should we add more?`, {
        expectsResponse: true,
        source: "teacher-redirect",
        intent: "ready",
        responseSeconds: 7.0
      });
    } else {
      await speakNow(TEACHER, `${childPrefix()}do you think this pizza is ready for the oven, or do you want to add more?`, {
        expectsResponse: true,
        source: "teacher",
        intent: "ready",
        responseSeconds: 7.0
      });
    }
  }

  function scheduleReadyReminder(delayMs) {
    clearReadyReminder();
    if (state.phase !== "making" || state.gameCompleted) return;
    readyReminderTimer = setTimeout(async function () {
      readyReminderTimer = null;
      if (state.phase !== "making" || state.isSpeaking || state.isListening || state.waitingForResponse) {
        scheduleReadyReminder(6500);
        return;
      }
      await speakNow(TEACHER, pickUnique("ready_reminder", [
        "If you're not ready yet, that's okay. Whenever you're ready, just let me know and we can put it in the oven.",
        "You can keep adding toppings if you want. When it feels ready, just say done and we can put it in the oven.",
        "No rush. Whenever the pizza feels ready, just tell me and we can put it in the oven.",
        "You can keep making it your way. When it feels finished, just say it is ready."
      ]));
      scheduleReadyReminder(READY_REMINDER_MS + Math.round(Math.random() * 6000));
    }, delayMs + Math.round(Math.random() * 4500));
  }

  function clearReadyReminder() {
    if (readyReminderTimer) clearTimeout(readyReminderTimer);
    readyReminderTimer = null;
  }

  function parseSliceCount(text) {
    const lower = cleanText(text).toLowerCase();
    if (/\b4\b|\bfour\b/.test(lower)) return 4;
    if (/\b6\b|\bsix\b/.test(lower)) return 6;
    if (/\b8\b|\beight\b/.test(lower)) return 8;
    return null;
  }

  function ingredientIdFromSpeech(text) {
    const lower = cleanText(text).toLowerCase();
    const aliases = [
      ["crustThin", ["thin", "thin crust"]],
      ["crustThick", ["thick", "thick crust"]],
      ["crustClassic", ["classic", "regular", "normal crust", "classic crust"]],
      ["tomatoSauce", ["tomato", "tomato sauce", "red sauce", "sauce"]],
      ["pestoSauce", ["pesto", "green sauce"]],
      ["whiteSauce", ["white sauce", "white"]],
      ["mozzarella", ["mozzarella"]],
      ["cheddar", ["cheddar"]],
      ["extraCheese", ["extra cheese", "lots of cheese", "more cheese"]],
      ["pepperoni", ["pepperoni"]],
      ["mushrooms", ["mushroom", "mushrooms"]],
      ["peppers", ["pepper", "peppers"]],
      ["olives", ["olive", "olives"]],
      ["pineapple", ["pineapple", "pineapples"]],
      ["tomatoes", ["tomato", "tomatoes"]],
      ["basil", ["basil"]],
      ["onions", ["onion", "onions"]]
    ];
    for (const [id, words] of aliases) {
      if (words.some(word => lower.includes(word))) return id;
    }
    return null;
  }

  function ingredientEmoji(id) {
    const emojis = {
      crustClassic: "🥖", crustThin: "🫓", crustThick: "🍞",
      tomatoSauce: "🍅", pestoSauce: "🌿", whiteSauce: "🥛",
      mozzarella: "🧀", cheddar: "🧀", extraCheese: "🧀",
      pepperoni: "🍕", mushrooms: "🍄", peppers: "🫑", olives: "🫒",
      pineapple: "🍍", tomatoes: "🍅", basil: "🌿", onions: "🧅"
    };
    return emojis[id] || "🍕";
  }

  function categoryForIngredient(id) {
    const item = INGREDIENTS[id];
    if (!item) return "sauce";
    if (item.kind === "topping") return "toppings";
    return item.kind;
  }

  function renderIngredientDock() {
    if (!ingredientDock) return;
    ingredientDock.innerHTML = "";

    const tabs = document.createElement("div");
    tabs.className = "ingredient-tabs";
    INGREDIENT_CATEGORIES.forEach(category => {
      const tab = document.createElement("button");
      tab.type = "button";
      tab.className = "ingredient-tab";
      tab.classList.toggle("active", category.id === activeIngredientCategory);
      tab.textContent = category.label;
      tab.addEventListener("click", function () {
        activeIngredientCategory = category.id;
        renderIngredientDock();
      });
      tabs.appendChild(tab);
    });

    const panel = document.createElement("div");
    panel.className = "ingredient-panel";
    const activeCategory = INGREDIENT_CATEGORIES.find(category => category.id === activeIngredientCategory) || INGREDIENT_CATEGORIES[1];
    const title = document.createElement("div");
    title.className = "ingredient-section-title";
    title.textContent = activeCategory.label;
    panel.appendChild(title);

    const row = document.createElement("div");
    row.className = "ingredient-row";
    activeCategory.ids.forEach(id => {
      const item = INGREDIENTS[id];
      if (!item) return;
      const button = document.createElement("button");
      button.type = "button";
      button.className = "ingredient-chip";
      button.dataset.ingredientId = id;
      button.classList.toggle("active", selectedIngredientId === id || (item.kind === "crust" && state.pizza.crust === id));

      const img = document.createElement("img");
      img.src = item.image;
      img.alt = "";
      img.addEventListener("error", function () { button.classList.add("image-failed"); }, { once: true });

      const emoji = document.createElement("span");
      emoji.className = "ingredient-emoji";
      emoji.textContent = ingredientEmoji(id);

      const label = document.createElement("span");
      label.className = "label";
      label.textContent = item.label;

      button.appendChild(img);
      button.appendChild(emoji);
      button.appendChild(label);
      button.addEventListener("click", () => selectIngredient(id));
      row.appendChild(button);
    });
    panel.appendChild(row);
    ingredientDock.appendChild(tabs);
    ingredientDock.appendChild(panel);
  }

  function updateHeader() {
    const order = currentOrder();
    if (orderTitle) orderTitle.textContent = order.name;
    if (orderNumber) orderNumber.textContent = String(state.orderIndex + 1);
  }

  function resizePizzaCanvas() {
    if (!pizzaCanvas || !pizzaCtx || !pizzaShell) return;
    const rect = pizzaShell.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    const dpr = Math.max(1, Math.min(2.25, window.devicePixelRatio || 1));
    const nextWidth = Math.round(rect.width * dpr);
    const nextHeight = Math.round(rect.height * dpr);
    if (pizzaCanvas.width !== nextWidth || pizzaCanvas.height !== nextHeight) {
      pizzaCanvas.width = nextWidth;
      pizzaCanvas.height = nextHeight;
      pizzaCanvas.style.width = `${rect.width}px`;
      pizzaCanvas.style.height = `${rect.height}px`;
    }
    pizzaCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  function pizzaGeometry() {
    const rect = pizzaShell.getBoundingClientRect();
    const size = Math.min(rect.width, rect.height);
    return {
      width: rect.width,
      height: rect.height,
      cx: rect.width / 2,
      cy: rect.height / 2,
      radius: size * 0.47
    };
  }

  function pointFromEvent(event) {
    const rect = pizzaShell.getBoundingClientRect();
    return { x: event.clientX - rect.left, y: event.clientY - rect.top };
  }

  function pointInsidePizza(point, factor = 0.91) {
    const { cx, cy, radius } = pizzaGeometry();
    const dx = point.x - cx;
    const dy = point.y - cy;
    return Math.sqrt(dx * dx + dy * dy) <= radius * factor;
  }

  function seededRandom(seedValue) {
    let seed = Math.floor(Math.abs(seedValue || 1)) % 2147483647;
    if (seed <= 0) seed += 2147483646;
    return function () {
      seed = seed * 16807 % 2147483647;
      return (seed - 1) / 2147483646;
    };
  }

  function clearPizzaCanvas() {
    if (!pizzaCtx || !pizzaCanvas) return;
    const rect = pizzaShell.getBoundingClientRect();
    pizzaCtx.clearRect(0, 0, rect.width, rect.height);
  }

  function drawCrustBase() {
    if (!pizzaCtx) return;
    const { cx, cy, radius } = pizzaGeometry();
    const crust = state.pizza.crust || "crustClassic";
    const styles = {
      crustClassic: { outer: "#b97631", mid: "#e3b765", inner: "#f1cf8b", rim: 18 },
      crustThin: { outer: "#c9873e", mid: "#e8c27a", inner: "#f4d797", rim: 9 },
      crustThick: { outer: "#9f5d22", mid: "#db9f4d", inner: "#f0c879", rim: 30 }
    };
    const style = styles[crust] || styles.crustClassic;

    pizzaCtx.save();
    pizzaCtx.beginPath();
    pizzaCtx.arc(cx, cy, radius, 0, Math.PI * 2);
    pizzaCtx.closePath();
    const gradient = pizzaCtx.createRadialGradient(cx - radius * 0.22, cy - radius * 0.28, radius * 0.08, cx, cy, radius);
    gradient.addColorStop(0, style.inner);
    gradient.addColorStop(0.70, style.mid);
    gradient.addColorStop(1, style.outer);
    pizzaCtx.fillStyle = gradient;
    pizzaCtx.fill();
    pizzaCtx.lineWidth = style.rim;
    pizzaCtx.strokeStyle = "rgba(151, 82, 28, 0.55)";
    pizzaCtx.stroke();
    pizzaCtx.globalAlpha = 0.24;
    pizzaCtx.fillStyle = "#fff7d6";
    pizzaCtx.beginPath();
    pizzaCtx.ellipse(cx - radius * 0.18, cy - radius * 0.25, radius * 0.34, radius * 0.17, -0.4, 0, Math.PI * 2);
    pizzaCtx.fill();
    pizzaCtx.restore();
  }

  function withPizzaClip(drawFn) {
    if (!pizzaCtx) return;
    const { cx, cy, radius } = pizzaGeometry();
    pizzaCtx.save();
    pizzaCtx.beginPath();
    pizzaCtx.arc(cx, cy, radius * 0.91, 0, Math.PI * 2);
    pizzaCtx.clip();
    drawFn();
    pizzaCtx.restore();
  }

  function sauceColor(id) {
    if (id === "pestoSauce") return "rgba(70, 138, 50, 0.76)";
    if (id === "whiteSauce") return "rgba(255, 246, 217, 0.74)";
    return "rgba(201, 45, 35, 0.76)";
  }

  function cheeseColor(id) {
    if (id === "cheddar") return "rgba(250, 186, 50, 0.92)";
    if (id === "extraCheese") return "rgba(255, 236, 144, 0.98)";
    return "rgba(255, 245, 184, 0.94)";
  }

  function drawSauce(op) {
    const rand = seededRandom(op.seed);
    const radius = 24 + rand() * 22;
    pizzaCtx.save();
    pizzaCtx.globalAlpha = op.baked ? 0.72 : 0.64;
    pizzaCtx.fillStyle = sauceColor(op.id);
    pizzaCtx.beginPath();
    pizzaCtx.ellipse(op.x + rand() * 10 - 5, op.y + rand() * 10 - 5, radius * (1.20 + rand() * 0.30), radius * (0.78 + rand() * 0.22), rand() * Math.PI, 0, Math.PI * 2);
    pizzaCtx.fill();
    pizzaCtx.restore();
  }

  function drawCheese(op) {
    const rand = seededRandom(op.seed);
    const strands = op.id === "extraCheese" ? 7 : 4;
    pizzaCtx.save();
    pizzaCtx.strokeStyle = cheeseColor(op.id);
    pizzaCtx.lineCap = "round";
    pizzaCtx.lineWidth = op.id === "extraCheese" ? 5 : 4;
    pizzaCtx.globalAlpha = op.baked ? 0.96 : 0.88;
    for (let i = 0; i < strands; i += 1) {
      const len = 14 + rand() * 28;
      const angle = rand() * Math.PI;
      const x = op.x + rand() * 50 - 25;
      const y = op.y + rand() * 50 - 25;
      pizzaCtx.beginPath();
      pizzaCtx.moveTo(x - Math.cos(angle) * len / 2, y - Math.sin(angle) * len / 2);
      pizzaCtx.lineTo(x + Math.cos(angle) * len / 2, y + Math.sin(angle) * len / 2);
      pizzaCtx.stroke();
    }
    pizzaCtx.restore();
  }

  function drawTopping(op) {
    const rand = seededRandom(op.seed);
    const size = 18 + rand() * 11;
    const x = op.x + rand() * 16 - 8;
    const y = op.y + rand() * 16 - 8;
    const angle = rand() * Math.PI;
    pizzaCtx.save();
    pizzaCtx.translate(x, y);
    pizzaCtx.rotate(angle);
    if (op.id === "pepperoni") {
      pizzaCtx.fillStyle = "#c7332b";
      pizzaCtx.beginPath();
      pizzaCtx.arc(0, 0, size * 0.60, 0, Math.PI * 2);
      pizzaCtx.fill();
      pizzaCtx.fillStyle = "rgba(255,255,255,0.18)";
      pizzaCtx.beginPath();
      pizzaCtx.arc(-size * 0.16, -size * 0.16, size * 0.13, 0, Math.PI * 2);
      pizzaCtx.fill();
    } else if (op.id === "mushrooms") {
      pizzaCtx.fillStyle = "#ead5bd";
      pizzaCtx.beginPath();
      pizzaCtx.ellipse(0, -size * 0.12, size * 0.55, size * 0.34, 0, Math.PI, 0);
      pizzaCtx.fill();
      pizzaCtx.fillStyle = "#d1ad88";
      pizzaCtx.fillRect(-size * 0.10, -size * 0.08, size * 0.20, size * 0.48);
    } else if (op.id === "peppers") {
      pizzaCtx.strokeStyle = "#2f9e44";
      pizzaCtx.lineWidth = 6;
      pizzaCtx.lineCap = "round";
      pizzaCtx.beginPath();
      pizzaCtx.arc(0, 0, size * 0.48, Math.PI * 0.12, Math.PI * 1.28);
      pizzaCtx.stroke();
    } else if (op.id === "olives") {
      pizzaCtx.strokeStyle = "#2f2926";
      pizzaCtx.lineWidth = 5;
      pizzaCtx.beginPath();
      pizzaCtx.arc(0, 0, size * 0.36, 0, Math.PI * 2);
      pizzaCtx.stroke();
    } else if (op.id === "pineapple") {
      pizzaCtx.fillStyle = "#facc15";
      pizzaCtx.beginPath();
      pizzaCtx.moveTo(0, -size * 0.58);
      pizzaCtx.lineTo(size * 0.55, size * 0.38);
      pizzaCtx.lineTo(-size * 0.55, size * 0.38);
      pizzaCtx.closePath();
      pizzaCtx.fill();
    } else if (op.id === "tomatoes") {
      pizzaCtx.fillStyle = "#ef4444";
      pizzaCtx.beginPath();
      pizzaCtx.arc(0, 0, size * 0.48, 0, Math.PI * 2);
      pizzaCtx.fill();
      pizzaCtx.fillStyle = "rgba(255,255,255,0.36)";
      pizzaCtx.beginPath();
      pizzaCtx.arc(-size * 0.14, -size * 0.12, size * 0.14, 0, Math.PI * 2);
      pizzaCtx.fill();
    } else if (op.id === "basil") {
      pizzaCtx.fillStyle = "#15803d";
      pizzaCtx.beginPath();
      pizzaCtx.ellipse(0, 0, size * 0.30, size * 0.68, 0, 0, Math.PI * 2);
      pizzaCtx.fill();
    } else if (op.id === "onions") {
      pizzaCtx.strokeStyle = "#f0d7ff";
      pizzaCtx.lineWidth = 4;
      pizzaCtx.beginPath();
      pizzaCtx.ellipse(0, 0, size * 0.47, size * 0.29, 0, 0, Math.PI * 2);
      pizzaCtx.stroke();
    }
    pizzaCtx.restore();
  }

  function drawOperation(op) {
    if (op.kind === "sauce") drawSauce(op);
    if (op.kind === "cheese") drawCheese(op);
    if (op.kind === "topping") drawTopping(op);
  }

  function renderPizza() {
    if (!pizzaCanvas || !pizzaCtx || !pizzaShell) return;
    resizePizzaCanvas();
    clearPizzaCanvas();
    pizzaShell.classList.toggle("baked", Boolean(state.pizza.baked));
    drawCrustBase();
    withPizzaClip(function () {
      (state.pizza.operations || []).forEach(drawOperation);
      if (state.pizza.baked) {
        const { cx, cy, radius } = pizzaGeometry();
        pizzaCtx.save();
        pizzaCtx.globalCompositeOperation = "multiply";
        pizzaCtx.fillStyle = "rgba(189, 110, 34, 0.15)";
        pizzaCtx.beginPath();
        pizzaCtx.arc(cx, cy, radius * 0.91, 0, Math.PI * 2);
        pizzaCtx.fill();
        pizzaCtx.restore();
      }
    });
  }

  function addOperation(kind, id, point) {
    const op = { kind, id, x: point.x, y: point.y, seed: Date.now() + Math.random() * 9999, baked: Boolean(state.pizza.baked) };
    state.pizza.operations.push(op);
    if (state.pizza.operations.length > 750) state.pizza.operations.splice(0, state.pizza.operations.length - 750);
    withPizzaClip(() => drawOperation(op));
    return op;
  }

  function brushAtEvent(event, options = {}) {
    if (state.phase !== "making" || state.pizza.baked || !selectedIngredientId) return;
    const item = INGREDIENTS[selectedIngredientId];
    if (!item || item.kind === "crust") return;
    const point = pointFromEvent(event);
    if (!pointInsidePizza(point)) return;
    const now = Date.now();
    const gap = item.kind === "sauce" ? 22 : item.kind === "cheese" ? 36 : 82;
    if (!options.force && now - lastBrushAt < gap) return;
    lastBrushAt = now;

    addOperation(item.kind, selectedIngredientId, point);
    if (item.kind === "sauce") state.pizza.sauceStamps += 1;
    if (item.kind === "cheese") state.pizza.cheeseStamps += 1;
    if (item.kind === "topping") {
      state.pizza.toppings.push({ id: selectedIngredientId, x: point.x, y: point.y });
      if (state.pizza.toppings.length > 260) state.pizza.toppings.splice(0, state.pizza.toppings.length - 260);
    }
    state.totalChoices += 1;
    orderInteractionCount += 1;
    maybeCharacterReactToMaking(selectedIngredientId);
    scheduleReadyReminder(READY_REMINDER_MS);
  }

  async function selectIngredient(id, options = {}) {
    const item = INGREDIENTS[id];
    if (!item || state.phase !== "making" || state.pizza.baked) return;
    selectedIngredientId = id;
    activeIngredientCategory = categoryForIngredient(id);
    page?.classList.remove("painting-active", "topping-brush-active");

    if (item.kind === "crust") {
      state.pizza.crust = id;
      state.totalChoices += 1;
      orderInteractionCount += 1;
      renderIngredientDock();
      renderPizza();
      await maybeCharacterReactToMaking(id, Boolean(options.fromSpeech));
      await saveProgress();
      scheduleReadyReminder(READY_REMINDER_MS);
      return;
    }

    renderIngredientDock();
    if (item.kind === "sauce" || item.kind === "cheese") {
      page?.classList.add("painting-active");
      updateQuietStatus(`Drag on the pizza to ${item.kind === "sauce" ? "spread" : "sprinkle"} ${item.label.toLowerCase()}`);
    } else if (item.kind === "topping") {
      page?.classList.add("topping-brush-active");
      updateQuietStatus(`Drag across the pizza to add ${item.label.toLowerCase()}`);
    }
    if (options.fromSpeech) await maybeCharacterReactToMaking(id, true);
  }

  function specificActionPhrase(id) {
    const item = INGREDIENTS[id];
    const name = item?.spoken || "that";
    if (!item) return "that choice";
    if (item.kind === "crust") return `choosing the ${name}`;
    if (item.kind === "sauce") return `spreading ${name}`;
    if (item.kind === "cheese") return `sprinkling ${name}`;
    return `adding ${name}`;
  }

  async function maybeCharacterReactToMaking(id, force = false) {
    const now = Date.now();
    if (!force && now - lastCharacterCommentAt < 7600 + Math.random() * 4200) return;
    if (state.isSpeaking || state.isListening || state.waitingForResponse || state.phase !== "making") return;
    lastCharacterCommentAt = now;

    const item = INGREDIENTS[id];
    const name = item?.spoken || "that";
    const action = specificActionPhrase(id);
    const mode = socialStage();
    const child = childPrefix();

    if (mode === "worker_observes") {
      await speakNow(WORKER, pickUnique(`observe_${id}`, [
        `${child}I see you ${action}. That's a great choice.`,
        `${child}nice work. I can see the ${name} on the pizza now.`,
        `${child}that ${name} is helping the pizza come together.`,
        `${child}good job. The pizza looks different with the ${name}.`,
        `${child}I like how you added the ${name}.`
      ]));
      return;
    }

    if (mode === "worker_wonders") {
      await speakNow(WORKER, pickUnique(`wonder_${id}`, [
        `I wonder if the ${name} will make this order look extra good.`,
        `I wonder where the ${name} should go next.`,
        `I wonder if this pizza needs a little more ${name} or something different.`,
        `I wonder what the customer will think when they see the ${name}.`,
        `Maybe the ${name} will be one of the best parts of this pizza.`
      ]));
      return;
    }

    if (mode === "worker_to_teacher_bridge") {
      if (!orderPromptAsked && orderInteractionCount >= 2) {
        orderPromptAsked = true;
        await speakNow(WORKER, pickUnique(`bridge_prompt_${id}`, [
          `Teacher, should we add more ${name}, or choose something different?`,
          `Teacher, what should we add after the ${name}?`,
          `Teacher, do you think this pizza needs another topping?`
        ]));
        await speakNow(TEACHER, `${child}what do you think? You can say one idea, or show us on the pizza.`, {
          expectsResponse: true,
          source: "teacher-redirect",
          intent: "ingredient",
          responseSeconds: 5.4
        });
        return;
      }
      await speakNow(WORKER, pickUnique(`bridge_${id}`, [
        `Teacher, I like how the ${name} looks here.`,
        `Teacher, the ${name} makes this pizza look more finished.`,
        `Teacher, I can see the ${name} now. That was a nice choice.`,
        `Teacher, this pizza changed a lot after the ${name}.`
      ]));
      return;
    }

    if (!orderPromptAsked && orderInteractionCount >= 1) {
      orderPromptAsked = true;
      await speakNow(WORKER, `${child}what should we add next? You can tell me one topping, or keep building it on the screen.`, {
        expectsResponse: true,
        source: "worker-direct",
        intent: "ingredient",
        responseSeconds: 5.8
      });
      return;
    }

    await speakNow(WORKER, pickUnique(`direct_${id}`, [
      `Nice choice. The ${name} looks good.`,
      `Great. I can see the ${name} on the pizza.`,
      `That is a good restaurant choice.`,
      `I like where you put the ${name}.`,
      `Good idea. The ${name} makes this pizza look special.`
    ]));
  }

  async function bakePizza() {
    if (state.pizza.baked || state.gameCompleted || state.phase === "baking") return;
    clearReadyReminder();
    stopPassiveDoneListen();
    state.phase = "baking";
    updateQuietStatus("Pizza is baking");

    await speakNow(WORKER, pickUnique("bake_start", [
      "Okay. I'll put it in the oven now.",
      "Great. This pizza is ready for the oven.",
      "Okay. Up to the oven it goes."
    ]));

    pizzaShell.classList.remove("back-from-oven");
    pizzaShell.classList.add("to-oven");
    await sleep(1350);

    await speakNow(TEACHER, pickUnique("baking_wait", [
      "It is baking now.",
      "We can wait while it bakes.",
      "It will come back down when it is ready."
    ]));

    await sleep(700);
    state.pizza.baked = true;
    state.pizza.operations.forEach(op => { op.baked = true; });
    pizzaShell.classList.remove("to-oven");
    pizzaShell.classList.add("back-from-oven", "baked");
    renderPizza();
    await sleep(840);
    pizzaShell.classList.remove("back-from-oven");

    await speakNow(WORKER, pickUnique("bake_done", [
      "The pizza is back from the oven.",
      "That pizza looks warm and ready.",
      "It came back looking nicely baked."
    ]));
    await askForSlices();
  }

  async function askForSlices() {
    state.phase = "slicing";
    sliceRetries = 0;
    const child = childPrefix();
    if (socialStage() === "worker_direct") {
      await speakNow(WORKER, `${child}how many slices should we cut it into? You can say four, six, or eight.`, {
        expectsResponse: true,
        source: "worker-direct",
        intent: "slice",
        responseSeconds: 6.4
      });
    } else if (socialStage() === "worker_to_teacher_bridge") {
      await speakNow(WORKER, "Teacher, how many slices should we cut it into?");
      await speakNow(TEACHER, `${child}what do you think, four, six, or eight slices?`, {
        expectsResponse: true,
        source: "teacher-redirect",
        intent: "slice",
        responseSeconds: 6.4
      });
    } else {
      await speakNow(TEACHER, `${child}how many slices should we cut this pizza into? You can say four, six, or eight.`, {
        expectsResponse: true,
        source: "teacher",
        intent: "slice",
        responseSeconds: 6.4
      });
    }
  }

  async function handleSliceNoAnswer() {
    if (state.phase !== "slicing" || state.gameCompleted) return;
    sliceRetries += 1;
    if (sliceRetries <= 1) {
      await speakNow(TEACHER, "I might have missed that. How many slices should we cut it into? Four, six, or eight?", {
        expectsResponse: true,
        source: "teacher-retry",
        intent: "slice",
        responseSeconds: 6.0
      });
      return;
    }
    await speakNow(TEACHER, "That's okay. We can do six slices for this one.");
    await chooseSlices(6, { defaulted: true });
  }

  function renderSliceLines(count) {
    if (!sliceLayer) return;
    sliceLayer.innerHTML = "";
    for (let i = 0; i < count; i += 1) {
      const line = document.createElement("div");
      line.className = "slice-line";
      line.style.transform = `translate(-50%, -50%) rotate(${(180 / count) * i}deg)`;
      sliceLayer.appendChild(line);
    }
  }

  async function chooseSlices(count, options = {}) {
    if (state.gameCompleted || state.phase !== "slicing") return;
    state.pizza.slices = count;
    renderSliceLines(count);
    state.phase = "finishing";
    await speakNow(WORKER, options.fromSpeech ? `Great. I'll cut it into ${count} slices.` : `Okay. ${count} slices.`);
    await sleep(650);
    await finishOrder();
  }

  async function finishOrder() {
    state.pizza.boxed = true;
    const order = currentOrder();
    await speakNow(WORKER, pickUnique(`finish_${order.id}`, [
      `${order.name} is finished. Thanks for helping.`,
      `That ${order.name.toLowerCase()} looks ready for the customer.`,
      `This order is ready. Nice work.`,
      `The customer is going to like this pizza.`
    ]));

    state.ordersCompleted = Math.max(state.ordersCompleted, state.orderIndex + 1);
    state.stepsCompleted += 1;
    await saveProgress({ orders_completed: state.ordersCompleted });

    if (state.orderIndex >= ORDERS.length - 1) {
      await finishActivity();
      return;
    }

    state.orderIndex += 1;
    clearForNewOrder();
    updateHeader();
    await sleep(650);
    await beginOrder();
  }

  function clearForNewOrder() {
    clearReadyReminder();
    state.pizza = freshPizzaState();
    state.phase = "making";
    selectedIngredientId = "tomatoSauce";
    activeIngredientCategory = "sauce";
    pointerDown = false;
    activePointerId = null;
    orderInteractionCount = 0;
    orderPromptAsked = false;
    sliceRetries = 0;
    page?.classList.remove("painting-active", "topping-brush-active");
    pizzaShell.classList.remove("to-oven", "back-from-oven", "baked");
    if (sliceLayer) sliceLayer.innerHTML = "";
    renderIngredientDock();
    renderPizza();
    updateQuietStatus("Pizza station ready");
  }

  function orderIntroLines() {
    const order = currentOrder();
    const child = childPrefix();
    const mode = socialStage();

    if (mode === "worker_observes") {
      return [
        [TEACHER, `${child}this order is ${order.name}. I can guide the pizza, and the restaurant worker can watch with us.`],
        [WORKER, `${child}I'll just watch this pizza and notice what you add. Thanks for helping me with the order.`],
        [TEACHER, "All of the pizza options are on the side. Choose one, then drag on the pizza to add it. Tell me when this pizza feels done."]
      ];
    }

    if (mode === "worker_wonders") {
      return [
        [TEACHER, `This order is ${order.name}. You can build it your way.`],
        [WORKER, `I wonder what choices will go on this ${order.name.toLowerCase()}.`],
        [TEACHER, "You do not have to answer yet. You can just build the pizza, and we will notice what you choose."]
      ];
    }

    if (mode === "worker_to_teacher_bridge") {
      return [
        [TEACHER, `This order is ${order.name}. The restaurant worker can ask me some things, and I can help pass the question to you.`],
        [WORKER, "Teacher, what should we add first?"],
        [TEACHER, `${child}what do you think we should start with? You can say one idea, or choose it on the side.`, { expectsResponse: true, source: "teacher-redirect", intent: "ingredient", responseSeconds: 5.8 }]
      ];
    }

    return [
      [TEACHER, `This order is ${order.name}. The restaurant worker can ask you more directly now, and I will stay right here.`],
      [WORKER, `${child}what should we add first for this pizza? You can tell me, or choose it on the side.`, { expectsResponse: true, source: "worker-direct", intent: "ingredient", responseSeconds: 5.8 }]
    ];
  }

  async function beginOrder() {
    orderInteractionCount = 0;
    orderPromptAsked = false;
    updateHeader();
    renderIngredientDock();
    renderPizza();
    schedulePassiveDoneListen(650);
    const lines = orderIntroLines();
    for (const [actor, text, options] of lines) {
      await speakNow(actor, text, options || {});
      await sleep(120);
    }
    scheduleReadyReminder(READY_REMINDER_MS);
  }

  async function finishActivity() {
    if (state.gameCompleted) return;
    state.gameCompleted = true;
    clearReadyReminder();
    stopPassiveDoneListen();
    await speakNow(TEACHER, "You helped finish all of the pizza orders today. I liked seeing how you worked with the restaurant worker.", { gameComplete: true });
    await speakNow(WORKER, "Thanks for helping me with the restaurant. You made a lot of great pizza choices today.", { gameComplete: true });

    const minutesPlayed = Math.max(0, (Date.now() - state.sessionStart) / 60000);
    try {
      const response = await fetch("/api/restaurant-game/complete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          activity_id: activityId,
          words_spoken: state.spokenWords,
          minutes_spoken: Math.max(0, state.spokenResponses * 0.08),
          active_minutes: minutesPlayed,
          time_spent_on_activity: minutesPlayed,
          spoken_responses: state.spokenResponses,
          silent_windows: state.silentWindows,
          orders_completed: TARGET_ORDERS,
          steps_completed: state.stepsCompleted,
          worker_direct_responses: state.workerDirectResponses,
          teacher_redirects: state.teacherRedirects,
          total_choices: state.totalChoices,
          last_pizza_json: JSON.stringify(state.pizza)
        })
      });
      const data = await response.json();
      if (data.success && data.next_activity_id) {
        window.location.href = `/activity/${data.next_activity_id}`;
        return;
      }
    } catch (error) {
      console.error("Could not complete restaurant game:", error);
    }
    window.location.href = "/dashboard";
  }

  async function saveProgress(extra = {}) {
    if (state.gameCompleted) return;
    try {
      await fetch("/api/restaurant-game/save-progress", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          activity_id: activityId,
          order_index: state.orderIndex,
          step_index: 0,
          orders_completed: state.ordersCompleted,
          steps_completed: state.stepsCompleted,
          spoken_responses: state.spokenResponses,
          silent_windows: state.silentWindows,
          worker_direct_responses: state.workerDirectResponses,
          teacher_redirects: state.teacherRedirects,
          total_choices: state.totalChoices,
          last_pizza_json: JSON.stringify(state.pizza),
          ...extra
        })
      });
    } catch (error) {
      console.warn("Could not save restaurant progress:", error);
    }
  }

  async function loadSavedProgress() {
    try {
      const response = await fetch(`/api/restaurant-game/state?activity_id=${activityId}`);
      if (!response.ok) return;
      const data = await response.json();
      if (!data.success || !data.state) return;
      const saved = data.state;
      state.orderIndex = Math.max(0, Math.min(ORDERS.length - 1, Number(saved.order_index || 0)));
      state.ordersCompleted = Math.max(0, Number(saved.orders_completed || 0));
      state.stepsCompleted = Math.max(0, Number(saved.steps_completed || 0));
      state.spokenResponses = Math.max(0, Number(saved.spoken_responses || 0));
      state.silentWindows = Math.max(0, Number(saved.silent_windows || 0));
      state.workerDirectResponses = Math.max(0, Number(saved.worker_direct_responses || 0));
      state.teacherRedirects = Math.max(0, Number(saved.teacher_redirects || 0));
      state.totalChoices = Math.max(0, Number(saved.total_choices || 0));
      if (saved.last_pizza_json) {
        try {
          const parsed = JSON.parse(saved.last_pizza_json);
          state.pizza = { ...freshPizzaState(), ...parsed, operations: Array.isArray(parsed.operations) ? parsed.operations : [] };
        } catch (error) {}
      }
    } catch (error) {
      console.warn("Could not load restaurant progress:", error);
    }
  }

  async function startGameAfterCall() {
    callAccepted = true;
    acceptCall.disabled = true;
    declineCall.disabled = true;
    stopRingtone();
    playCallAcceptedSound();
    ensureMicPermission();
    await loadSavedProgress();
    updateHeader();
    renderIngredientDock();
    renderPizza();

    introScreen.classList.remove("hidden");
    if (screenShareLoading) screenShareLoading.classList.add("hidden");
    if (introSplit) introSplit.classList.remove("hidden");

    requestAnimationFrame(() => incomingCallScreen.classList.add("hide"));
    setTimeout(() => { incomingCallScreen.style.display = "none"; }, 450);
    setTimeout(playIntro, 820);
  }

  async function playIntro() {
    await speakNow(TEACHER, "Hey, it's me again, the Teacher. Today I am here with someone from the restaurant.");
    await speakNow(WORKER, "Hi. I'm working on some pizza orders today, and I could really use some help.");
    await speakNow(TEACHER, "I'll stay here with you while we help make the pizzas.");

    if (introSplit) introSplit.classList.add("hidden");
    if (screenShareLoading) screenShareLoading.classList.remove("hidden");
    await sleep(1200);
    shrinkIntroToGame();
  }

  function shrinkIntroToGame() {
    stopMouthAnimation();
    requestAnimationFrame(() => introScreen.classList.add("shrink"));
    setTimeout(() => zoomStage.classList.remove("call-hidden"), 760);
    setTimeout(() => {
      introScreen.style.display = "none";
      introScreen.classList.add("hidden");
      zoomStage.classList.remove("side-panel-hidden");
      closeAllMouths();
      renderPizza();
      beginOrder();
    }, 1250);
  }

  function cleanupMedia() {
    clearReadyReminder();
    stopPassiveDoneListen();
    stopResponseWindow();
    stopMouthAnimation();
    if (currentAudio) {
      currentAudio.pause();
      currentAudio = null;
    }
    if (mediaStream) {
      mediaStream.getTracks().forEach(track => track.stop());
      mediaStream = null;
    }
  }

  resetPizzaBtn.addEventListener("click", async function () {
    if (state.phase === "baking" || state.phase === "finishing") return;
    clearForNewOrder();
    await saveProgress();
    await speakNow(TEACHER, "Okay. We can restart this pizza.");
    scheduleReadyReminder(READY_REMINDER_MS);
  });

  function handlePointerDown(event) {
    if (state.phase !== "making") return;
    pointerDown = true;
    activePointerId = event.pointerId;
    pizzaCanvas.setPointerCapture?.(event.pointerId);
    event.preventDefault();
    brushAtEvent(event, { force: true });
  }

  function handlePointerMove(event) {
    if (!pointerDown || activePointerId !== event.pointerId) return;
    event.preventDefault();
    brushAtEvent(event);
  }

  function handlePointerUp(event) {
    if (activePointerId !== null && activePointerId !== event.pointerId) return;
    if (pointerDown) saveProgress();
    pointerDown = false;
    activePointerId = null;
  }

  pizzaCanvas.addEventListener("pointerdown", handlePointerDown);
  pizzaCanvas.addEventListener("pointermove", handlePointerMove);
  pizzaCanvas.addEventListener("pointerup", handlePointerUp);
  pizzaCanvas.addEventListener("pointercancel", handlePointerUp);
  window.addEventListener("pointerup", function () {
    if (pointerDown) saveProgress();
    pointerDown = false;
    activePointerId = null;
  });

  window.addEventListener("resize", function () {
    renderPizza();
  });

  acceptCall.addEventListener("click", startGameAfterCall);
  declineCall.addEventListener("click", dashboardFade);
  hangupButton.addEventListener("click", dashboardFade);

  document.addEventListener("pointerdown", startRingtone, { once: true });
  setTimeout(startRingtone, 450);
  preloadWorkerFrames();
  updateHeader();
  renderIngredientDock();
  requestAnimationFrame(renderPizza);
});
