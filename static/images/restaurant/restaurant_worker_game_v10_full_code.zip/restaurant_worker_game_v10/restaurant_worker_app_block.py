# =========================
# Restaurant Worker Pizza Game V9 — Teacher + Restaurant Worker bridge activity
# Frontend routes:
#   /restaurant-worker-game
#   /api/restaurant-game/tts
#   /api/restaurant-game/transcribe
#   /api/restaurant-game/state
#   /api/restaurant-game/save-progress
#   /api/restaurant-game/complete
#
# Requires:
#   templates/restaurant_worker_game.html
#   static/css/restaurant_worker_game.css
#   static/js/restaurant_worker_game.js
#   static/images/restaurant/* assets listed in README_assets_and_setup.md
# =========================

RESTAURANT_GAME_TARGET_ORDERS = 8


def ensure_restaurant_game_progress_columns():
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("PRAGMA table_info(progress)")
    existing_columns = {row["name"] for row in cursor.fetchall()}

    columns_to_add = {
        "restaurant_order_index": "ALTER TABLE progress ADD COLUMN restaurant_order_index INTEGER DEFAULT 0",
        "restaurant_step_index": "ALTER TABLE progress ADD COLUMN restaurant_step_index INTEGER DEFAULT 0",
        "restaurant_orders_completed": "ALTER TABLE progress ADD COLUMN restaurant_orders_completed INTEGER DEFAULT 0",
        "restaurant_steps_completed": "ALTER TABLE progress ADD COLUMN restaurant_steps_completed INTEGER DEFAULT 0",
        "restaurant_spoken_responses": "ALTER TABLE progress ADD COLUMN restaurant_spoken_responses INTEGER DEFAULT 0",
        "restaurant_silent_windows": "ALTER TABLE progress ADD COLUMN restaurant_silent_windows INTEGER DEFAULT 0",
        "restaurant_worker_direct_responses": "ALTER TABLE progress ADD COLUMN restaurant_worker_direct_responses INTEGER DEFAULT 0",
        "restaurant_teacher_redirects": "ALTER TABLE progress ADD COLUMN restaurant_teacher_redirects INTEGER DEFAULT 0",
        "restaurant_total_choices": "ALTER TABLE progress ADD COLUMN restaurant_total_choices INTEGER DEFAULT 0",
        "restaurant_last_pizza_json": "ALTER TABLE progress ADD COLUMN restaurant_last_pizza_json TEXT",
        "restaurant_last_played_at": "ALTER TABLE progress ADD COLUMN restaurant_last_played_at TEXT"
    }

    for column_name, alter_sql in columns_to_add.items():
        if column_name not in existing_columns:
            cursor.execute(alter_sql)

    conn.commit()
    conn.close()


def safe_restaurant_int(value, default=0, max_value=9999):
    try:
        parsed = int(float(value if value is not None else default))
    except (TypeError, ValueError):
        parsed = default

    return max(0, min(max_value, parsed))


def safe_restaurant_float(value, default=0.0):
    try:
        return max(0.0, float(value if value is not None else default))
    except (TypeError, ValueError):
        return default


def sanitize_restaurant_game_line(text, fallback="Nice choice.", max_len=260):
    text = re.sub(r"\s+", " ", str(text or "")).strip()
    text = text.replace('"', "")[:max_len]

    if not text:
        return fallback

    banned_terms = [
        "selective mutism",
        "anxiety",
        "therapy",
        "treatment",
        "exposure",
        "diagnosis",
        "progress",
        "bravery",
        "confidence",
        "use your words"
    ]

    lowered = text.lower()

    if any(term in lowered for term in banned_terms):
        return fallback

    return text


def generate_restaurant_game_voice_elevenlabs(text, speaker="teacher", game_complete=False):
    speaker = str(speaker or "teacher").strip().lower()

    if speaker in {"worker", "waiter", "restaurantworker", "chef"}:
        # Same voice source/settings as the Toy Store Worker / Guessing Game 2 block.
        voice_id = os.getenv("TOY_TRIVIA_VOICE_ID") or os.getenv("TOY_WORKER_VOICE_ID")

        if not voice_id:
            voice_id = os.getenv("ELEVENLABS_VOICE_ID", "piI8Kku0DcvcL6TTSeQt")

        if game_complete:
            voice_settings = {
                "stability": 0.84,
                "similarity_boost": 0.90,
                "style": 0.25,
                "use_speaker_boost": False
            }
        else:
            voice_settings = {
                "stability": 0.94,
                "similarity_boost": 0.90,
                "style": 0.06,
                "use_speaker_boost": False
            }
    else:
        voice_id = (
            os.getenv("LIBRARIAN_VOICE_ID")
            or os.getenv("BOOK_GUESSING_VOICE_ID")
            or os.getenv("ELEVENLABS_VOICE_ID", "piI8Kku0DcvcL6TTSeQt")
        )
        voice_settings = {
            "stability": 0.96,
            "similarity_boost": 0.90,
            "style": 0.03,
            "use_speaker_boost": False
        }

    response = eleven_client.text_to_speech.convert(
        voice_id=voice_id,
        text=text,
        model_id="eleven_multilingual_v2",
        output_format="mp3_44100_128",
        voice_settings=voice_settings
    )

    return b"".join(response)


@app.route("/restaurant-worker-game")
@login_required
def restaurant_worker_game_preview():
    return render_template(
        "restaurant_worker_game.html",
        activity=None,
        parent=session.get("parent_name", ""),
        child=session.get("child_name", ""),
        active_page="dashboard",
        profile_icon=session.get("profile_icon", "profileicon.png")
    )


@app.route("/api/restaurant-game/tts", methods=["POST"])
@csrf.exempt
@login_required
@limiter.limit("60 per minute")
def restaurant_game_tts():
    data = request.get_json(silent=True) or {}

    speaker = str(data.get("speaker", "teacher")).strip().lower()
    text = sanitize_restaurant_game_line(data.get("text", ""), fallback="Nice choice.")
    game_complete = bool(data.get("game_complete", False))

    if speaker not in {"teacher", "worker", "waiter", "restaurantworker", "chef"}:
        speaker = "teacher"

    if not text:
        return jsonify({"success": False, "error": "Missing text"}), 400

    try:
        audio_bytes = generate_restaurant_game_voice_elevenlabs(
            text,
            speaker=speaker,
            game_complete=game_complete
        )
        audio_base64 = base64.b64encode(audio_bytes).decode("utf-8")

        return jsonify({
            "success": True,
            "speaker": speaker,
            "message": text,
            "audio": f"data:audio/mpeg;base64,{audio_base64}"
        })

    except Exception as e:
        print("Restaurant game TTS error:", repr(e))
        return jsonify({"success": False, "error": "Could not generate restaurant game audio"}), 500


@app.route("/api/restaurant-game/transcribe", methods=["POST"])
@csrf.exempt
@login_required
@limiter.limit("30 per minute")
def restaurant_game_transcribe():
    if "audio" not in request.files:
        return jsonify({"success": False, "error": "Missing audio"}), 400

    audio_file = request.files["audio"]

    try:
        import io

        audio_bytes = audio_file.read()

        if not audio_bytes:
            return jsonify({"success": False, "error": "Empty audio file"}), 400

        file_obj = io.BytesIO(audio_bytes)
        file_obj.name = "restaurant-response.webm"

        transcript = client.audio.transcriptions.create(
            model="gpt-4o-mini-transcribe",
            file=file_obj
        )

        text = transcript.text.strip()
        print("RESTAURANT GAME TRANSCRIPT:", text)

        return jsonify({"success": True, "text": text})

    except Exception as e:
        print("Restaurant game transcription error:", repr(e))
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/restaurant-game/state", methods=["GET"])
@csrf.exempt
@login_required
def restaurant_game_state():
    ensure_restaurant_game_progress_columns()

    activity_id = safe_restaurant_int(request.args.get("activity_id"), 10, 9999)

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT
            COALESCE(restaurant_order_index, 0) AS order_index,
            COALESCE(restaurant_step_index, 0) AS step_index,
            COALESCE(restaurant_orders_completed, 0) AS orders_completed,
            COALESCE(restaurant_steps_completed, 0) AS steps_completed,
            COALESCE(restaurant_spoken_responses, 0) AS spoken_responses,
            COALESCE(restaurant_silent_windows, 0) AS silent_windows,
            COALESCE(restaurant_worker_direct_responses, 0) AS worker_direct_responses,
            COALESCE(restaurant_teacher_redirects, 0) AS teacher_redirects,
            COALESCE(restaurant_total_choices, 0) AS total_choices,
            COALESCE(restaurant_last_pizza_json, '') AS last_pizza_json,
            COALESCE(is_completed, 0) AS is_completed
        FROM progress
        WHERE user_id = ? AND activity_id = ?
    """, (session["user_id"], activity_id))

    row = cursor.fetchone()

    if not row:
        cursor.execute("""
            INSERT OR IGNORE INTO progress (
                user_id,
                activity_id,
                is_unlocked,
                is_completed,
                words_spoken,
                minutes_spoken,
                active_minutes,
                time_spent_on_activity
            )
            VALUES (?, ?, 1, 0, 0, 0, 0, 0)
        """, (session["user_id"], activity_id))
        conn.commit()

        state = {
            "order_index": 0,
            "step_index": 0,
            "orders_completed": 0,
            "steps_completed": 0,
            "spoken_responses": 0,
            "silent_windows": 0,
            "worker_direct_responses": 0,
            "teacher_redirects": 0,
            "total_choices": 0,
            "last_pizza_json": "",
            "is_completed": 0
        }
    else:
        state = dict(row)

    conn.close()

    return jsonify({
        "success": True,
        "target_orders": RESTAURANT_GAME_TARGET_ORDERS,
        "state": state
    })


@app.route("/api/restaurant-game/save-progress", methods=["POST"])
@csrf.exempt
@login_required
@limiter.limit("60 per minute")
def restaurant_game_save_progress():
    ensure_restaurant_game_progress_columns()

    data = request.get_json(silent=True) or {}

    activity_id = safe_restaurant_int(data.get("activity_id"), 10, 9999)
    order_index = safe_restaurant_int(data.get("order_index"), 0, 7)
    step_index = safe_restaurant_int(data.get("step_index"), 0, 8)
    orders_completed = safe_restaurant_int(data.get("orders_completed"), 0, RESTAURANT_GAME_TARGET_ORDERS)
    steps_completed = safe_restaurant_int(data.get("steps_completed"), 0, 80)
    spoken_responses = safe_restaurant_int(data.get("spoken_responses"), 0, 9999)
    silent_windows = safe_restaurant_int(data.get("silent_windows"), 0, 9999)
    worker_direct_responses = safe_restaurant_int(data.get("worker_direct_responses"), 0, 9999)
    teacher_redirects = safe_restaurant_int(data.get("teacher_redirects"), 0, 9999)
    total_choices = safe_restaurant_int(data.get("total_choices"), 0, 9999)
    last_pizza_json = str(data.get("last_pizza_json", "") or "")[:16000]

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("""
            INSERT OR IGNORE INTO progress (
                user_id,
                activity_id,
                is_unlocked,
                is_completed,
                words_spoken,
                minutes_spoken,
                active_minutes,
                time_spent_on_activity
            )
            VALUES (?, ?, 1, 0, 0, 0, 0, 0)
        """, (session["user_id"], activity_id))

        cursor.execute("""
            UPDATE progress
            SET
                restaurant_order_index = ?,
                restaurant_step_index = ?,
                restaurant_orders_completed = MAX(COALESCE(restaurant_orders_completed, 0), ?),
                restaurant_steps_completed = MAX(COALESCE(restaurant_steps_completed, 0), ?),
                restaurant_spoken_responses = MAX(COALESCE(restaurant_spoken_responses, 0), ?),
                restaurant_silent_windows = MAX(COALESCE(restaurant_silent_windows, 0), ?),
                restaurant_worker_direct_responses = MAX(COALESCE(restaurant_worker_direct_responses, 0), ?),
                restaurant_teacher_redirects = MAX(COALESCE(restaurant_teacher_redirects, 0), ?),
                restaurant_total_choices = MAX(COALESCE(restaurant_total_choices, 0), ?),
                restaurant_last_pizza_json = ?,
                restaurant_last_played_at = ?
            WHERE user_id = ? AND activity_id = ?
        """, (
            order_index,
            step_index,
            orders_completed,
            steps_completed,
            spoken_responses,
            silent_windows,
            worker_direct_responses,
            teacher_redirects,
            total_choices,
            last_pizza_json,
            datetime.now().isoformat(timespec="seconds"),
            session["user_id"],
            activity_id
        ))

        conn.commit()
        conn.close()

        return jsonify({"success": True})

    except Exception as e:
        conn.rollback()
        conn.close()
        print("Restaurant game save progress error:", repr(e))
        return jsonify({"success": False, "error": "Could not save restaurant progress"}), 500


@app.route("/api/restaurant-game/complete", methods=["POST"])
@csrf.exempt
@login_required
@limiter.limit("20 per minute")
def restaurant_game_complete():
    ensure_restaurant_game_progress_columns()

    data = request.get_json(silent=True) or {}

    try:
        activity_id = safe_restaurant_int(data.get("activity_id"), 10, 9999)
        words_spoken = safe_restaurant_int(data.get("words_spoken"), 0, 999999)
        minutes_spoken = safe_restaurant_float(data.get("minutes_spoken"), 0.0)
        active_minutes = safe_restaurant_float(data.get("active_minutes"), 0.0)
        time_spent = safe_restaurant_float(data.get("time_spent_on_activity"), active_minutes)
        spoken_responses = safe_restaurant_int(data.get("spoken_responses"), 0, 9999)
        silent_windows = safe_restaurant_int(data.get("silent_windows"), 0, 9999)
        worker_direct_responses = safe_restaurant_int(data.get("worker_direct_responses"), 0, 9999)
        teacher_redirects = safe_restaurant_int(data.get("teacher_redirects"), 0, 9999)
        total_choices = safe_restaurant_int(data.get("total_choices"), 0, 9999)
        orders_completed = safe_restaurant_int(data.get("orders_completed"), RESTAURANT_GAME_TARGET_ORDERS, RESTAURANT_GAME_TARGET_ORDERS)
        steps_completed = safe_restaurant_int(data.get("steps_completed"), 0, 80)
    except Exception:
        return jsonify({"success": False, "error": "Invalid completion data"}), 400

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("""
            SELECT scene_id, activity_order
            FROM activity
            WHERE activity_id = ?
        """, (activity_id,))
        activity = cursor.fetchone()

        cursor.execute("""
            INSERT OR IGNORE INTO progress (
                user_id,
                activity_id,
                is_unlocked,
                is_completed,
                words_spoken,
                minutes_spoken,
                active_minutes,
                time_spent_on_activity
            )
            VALUES (?, ?, 1, 0, 0, 0, 0, 0)
        """, (session["user_id"], activity_id))

        cursor.execute("""
            UPDATE progress
            SET
                is_completed = 1,
                words_spoken = COALESCE(words_spoken, 0) + ?,
                minutes_spoken = COALESCE(minutes_spoken, 0) + ?,
                active_minutes = COALESCE(active_minutes, 0) + ?,
                time_spent_on_activity = COALESCE(time_spent_on_activity, 0) + ?,
                restaurant_orders_completed = MAX(COALESCE(restaurant_orders_completed, 0), ?),
                restaurant_steps_completed = MAX(COALESCE(restaurant_steps_completed, 0), ?),
                restaurant_spoken_responses = MAX(COALESCE(restaurant_spoken_responses, 0), ?),
                restaurant_silent_windows = MAX(COALESCE(restaurant_silent_windows, 0), ?),
                restaurant_worker_direct_responses = MAX(COALESCE(restaurant_worker_direct_responses, 0), ?),
                restaurant_teacher_redirects = MAX(COALESCE(restaurant_teacher_redirects, 0), ?),
                restaurant_total_choices = MAX(COALESCE(restaurant_total_choices, 0), ?),
                restaurant_last_played_at = ?
            WHERE user_id = ? AND activity_id = ?
        """, (
            words_spoken,
            minutes_spoken,
            active_minutes,
            time_spent,
            orders_completed,
            steps_completed,
            spoken_responses,
            silent_windows,
            worker_direct_responses,
            teacher_redirects,
            total_choices,
            datetime.now().isoformat(timespec="seconds"),
            session["user_id"],
            activity_id
        ))

        next_activity_id = None

        if activity:
            cursor.execute("""
                SELECT activity_id
                FROM activity
                WHERE is_active = 1
                  AND (
                    scene_id > ?
                    OR (scene_id = ? AND activity_order > ?)
                  )
                ORDER BY scene_id ASC, activity_order ASC
                LIMIT 1
            """, (
                activity["scene_id"],
                activity["scene_id"],
                activity["activity_order"]
            ))

            next_activity = cursor.fetchone()

            if next_activity:
                next_activity_id = next_activity["activity_id"]

                cursor.execute("""
                    INSERT OR IGNORE INTO progress (
                        user_id,
                        activity_id,
                        is_unlocked,
                        is_completed,
                        words_spoken,
                        minutes_spoken,
                        active_minutes,
                        time_spent_on_activity
                    )
                    VALUES (?, ?, 1, 0, 0, 0, 0, 0)
                """, (session["user_id"], next_activity_id))

                cursor.execute("""
                    UPDATE progress
                    SET is_unlocked = 1
                    WHERE user_id = ? AND activity_id = ?
                """, (session["user_id"], next_activity_id))

                cursor.execute("""
                    UPDATE users
                    SET current_activity_id = ?
                    WHERE user_id = ?
                """, (next_activity_id, session["user_id"]))

        conn.commit()
        conn.close()

        return jsonify({
            "success": True,
            "next_activity_id": next_activity_id,
            "target_orders": RESTAURANT_GAME_TARGET_ORDERS
        })

    except Exception as e:
        conn.rollback()
        conn.close()
        print("Restaurant game completion error:", repr(e))
        return jsonify({"success": False, "error": "Could not save restaurant game completion"}), 500
