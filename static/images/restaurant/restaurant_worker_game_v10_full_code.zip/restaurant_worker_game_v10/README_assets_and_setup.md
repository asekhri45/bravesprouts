# Restaurant Worker Game V9 — Setup Notes

This version focuses on fixing the actual pizza-making engine and strengthening the Teacher → Restaurant Worker social progression.

## Copy files

Place these files in your project:

- `templates/restaurant_worker_game.html`
- `static/css/restaurant_worker_game.css`
- `static/js/restaurant_worker_game.js`

If your current `app.py` has changed, do not blindly replace the whole file. Use `restaurant_worker_app_block.py` and paste/replace the Restaurant Worker block in your current `app.py`.

## Required existing assets

The game reuses Drawing Game-style assets:

- `static/images/librarian.png`
- `static/images/librarianpfp.png`
- `static/images/librarian-mouth-closed.png`
- `static/images/librarybg.png`
- `static/images/ringtone.mp3`
- `static/images/call_accepted.mp3`

## Restaurant assets

Create/upload these files:

- `static/images/restaurant/restaurant-bg.png`
- `static/images/restaurant/restaurant-worker.png`
- `static/images/restaurant/restaurant-worker-pfp.png`
- `static/images/restaurant/restaurant-worker-mouth-closed.png`

Optional ingredient thumbnails. The pizza canvas still works without these because V9 draws the actual sauce, cheese, crust, and toppings directly on canvas:

- `static/images/restaurant/crust-classic.png`
- `static/images/restaurant/crust-thin.png`
- `static/images/restaurant/crust-thick.png`
- `static/images/restaurant/sauce-tomato-stamp.png`
- `static/images/restaurant/sauce-pesto-stamp.png`
- `static/images/restaurant/sauce-white-stamp.png`
- `static/images/restaurant/cheese-mozzarella-stamp.png`
- `static/images/restaurant/cheese-cheddar-stamp.png`
- `static/images/restaurant/cheese-extra-stamp.png`
- `static/images/restaurant/topping-pepperoni.png`
- `static/images/restaurant/topping-mushroom.png`
- `static/images/restaurant/topping-pepper.png`
- `static/images/restaurant/topping-olive.png`
- `static/images/restaurant/topping-pineapple.png`
- `static/images/restaurant/topping-tomato.png`
- `static/images/restaurant/topping-basil.png`
- `static/images/restaurant/topping-onion.png`

## Voice

Restaurant Worker uses the Toy Store Worker voice environment variables:

- `TOY_TRIVIA_VOICE_ID`
- or `TOY_WORKER_VOICE_ID`

Teacher uses the librarian/book guessing voice fallback.

## V9 behavior changes

- Crust selection now redraws the canvas visibly.
- Sauce is a true paintbrush on the pizza canvas.
- Cheese is a true sprinkle/brush on the pizza canvas.
- Toppings are brush-based and do not require image uploads to function.
- Saying “I’m done” starts the ready-for-oven confirmation.
- Saying “yes,” “ready,” “put it in the oven,” or “bake it” during confirmation now triggers the oven animation.
- The pizza moves up off screen and returns baked; no oven image is used.
- Worker comments are ingredient-specific and less repetitive.
- Child name is used warmly in the first two orders.
- Social progression is enforced across 8 orders:
  - Orders 1–2: Worker observes and uses warm, specific comments.
  - Orders 3–4: Worker uses “I wonder” language without requiring a response.
  - Orders 5–6: Worker asks Teacher, Teacher redirects to the child.
  - Orders 7–8: Worker asks the child directly while Teacher remains present.


## Restaurant Worker mouth-frame assets - V10

The Restaurant Worker no longer uses a separate transparent mouth overlay. Use full character frames instead:

- `static/images/restaurant/restaurant-worker-mouth-small.png` — default/closed-small mouth frame
- `static/images/restaurant/restaurant-worker-mouth-medium.png` — medium mouth frame
- `static/images/restaurant/restaurant-worker-mouth-large.png` — large mouth frame
- `static/images/restaurant/restaurant-worker-mouth-extra-large.png` — widest mouth frame

Optional fallback filenames supported by the JavaScript:

- Medium: `restaurant-worker-mouth-mid.png`
- Large: `restaurant-worker-mouth-open.png`
- Extra-large: `restaurant-worker-mouth-xlarge.png` or `restaurant-worker-mouth-wide.png`

The Teacher still uses the old separate-mouth overlay system.
