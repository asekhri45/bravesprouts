Restaurant Worker Game v8

Replace these files:
- static/js/restaurant_worker_game.js
- static/css/restaurant_worker_game.css

No app.py changes are included.

Main updates:
- Removed the extra/back salad bowl so only the working bowl remains.
- Kept salad pieces behind the bowl front so they sit partly inside and partly above the rim.
- Changed ready wording from Leo-focused to customer-focused.
- Removed character lines that call attention to asking questions.
- Rounds 5 and 6 now use casual Leo preference prompts.
- If the child is silent, Teacher answers first and gently redirects to the child.
- After the child says done in later rounds, Leo asks the move-on/keep-working choice using “do you guys,” and Teacher bridges only if needed.
